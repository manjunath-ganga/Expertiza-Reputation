class CsEntriesAdaptor
   attr_accessor :participant_id
   attr_accessor :total_score
   attr_accessor :questionnaire_id
end