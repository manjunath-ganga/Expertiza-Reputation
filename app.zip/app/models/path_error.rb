class PathError < StandardError
end
