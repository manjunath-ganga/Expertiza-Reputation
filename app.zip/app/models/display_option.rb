class DisplayOption
  attr_accessor :name
end