class ResubmissionTime < ActiveRecord::Base
end
