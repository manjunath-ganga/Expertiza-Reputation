class TreeFolder < ActiveRecord::Base
end
