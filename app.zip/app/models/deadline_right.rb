class DeadlineRight < ActiveRecord::Base
end
