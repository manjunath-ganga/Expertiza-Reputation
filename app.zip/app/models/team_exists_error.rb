class TeamExistsError < StandardError
end
