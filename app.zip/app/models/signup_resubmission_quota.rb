class SignupResubmissionQuota < ActiveRecord::Base
end
