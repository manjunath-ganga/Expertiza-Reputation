class DeadlineType < ActiveRecord::Base
end
