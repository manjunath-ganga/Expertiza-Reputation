class SurveyParticipant < ActiveRecord::Base
end
