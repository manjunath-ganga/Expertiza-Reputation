class QuestionAdvice < ActiveRecord::Base
  belongs_to :question
end
