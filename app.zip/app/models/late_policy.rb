class LatePolicy < ActiveRecord::Base
  belongs_to :due_date
end
