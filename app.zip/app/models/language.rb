class Language < ActiveRecord::Base
end
