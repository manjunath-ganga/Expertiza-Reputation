class Waitlist < ActiveRecord::Base
end
