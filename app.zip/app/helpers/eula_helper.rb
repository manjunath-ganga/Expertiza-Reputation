module EulaHelper
end
