module PublishingHelper
end
